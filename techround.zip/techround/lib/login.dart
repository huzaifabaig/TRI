import 'package:flutter/material.dart';
import 'package:techround/home.dart';

List<String> user = [
  "select",
];

// Login Screen...

class loginScreen extends StatefulWidget {
  const loginScreen({super.key});

  @override
  State<loginScreen> createState() => _loginScreenState();
}

class _loginScreenState extends State<loginScreen> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 40,
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextField(
            controller: name,
            decoration: const InputDecoration(
              hintText: '@email',
            ),
          ),
          TextField(
            controller: email,
            decoration: const InputDecoration(
              hintText: 'password',
            ),
          ),
          const SizedBox(
            height: 40,
          ),
          TextButton(
              style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.resolveWith(
                      (states) => Colors.red)),
              onPressed: () {
                user.add(name.text);
                user.add(email.text);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const HomeScreen()));
                setState(() {});
              },
              child: const Text('Login'))
        ]),
      ),
    );
  }
}
